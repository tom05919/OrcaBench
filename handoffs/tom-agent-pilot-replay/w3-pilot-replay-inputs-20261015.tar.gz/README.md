# W3 pilot replay inputs for W1 (issue #9)

Private research data: share privately with Tom; never commit or attach to the public repository.

Extract from the OrcaBench checkout root with `tar -xzf /path/to/w3-pilot-replay-inputs-20261015.tar.gz`. Inspect existing source paths before extracting. Relative paths are preserved so inputs.json episode, experience and timing paths resolve directly.

From the extraction root verify files with `shasum -a 256 -c SHA256SUMS`. manifest.json records hashes, sizes and per-episode counts. Includes eight episode folders, 27 observations, observations.jsonl/result.json/decisions.jsonl per episode, only PNGs referenced in observations, plus original calibration inputs.json and its nine input JSON files.

The timing copy is the common 4.7-second public input used for original replay calibration, not a newly measured add-on charge. Use each episode's own preceding experience. source_hashes are historical provenance; source code, model configs and earlier replay outputs are deliberately not bundled. Videos, evaluator directories, credentials and other run artifacts are excluded.

No replay call or upload was made to create this bundle.
